<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Resto_model extends CI_Model{
	
	function checkEmployeeByUsername($username,$password){
	   $query = $this->db->query("SELECT * from tb_employee e join tb_employee_detail ed on e.id_employee=ed.id_employee where e.username='$username' and e.password='$password'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
	       }
        }

        function checkEmployeeByID($id_employee){
            $query = $this->db->query("SELECT * from tb_employee e join tb_employee_detail ed on e.id_employee=ed.id_employee where e.id_employee='$id_employee' "); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function login($username,$password){
            $query = $this->db->query("SELECT * from tb_employee where username='$username' and password='$password'"); 
                return $query->result() ;
                      
        }

        function getEmployee($id_employee){
            $query = $this->db->query("SELECT e.id_employee,ed.name,ed.birthPlace,ed.birthDay,ed.lastEducation,e.id_position,p.name as position,e.username,e.password,e.contractStart,e.contractEnd,p.salary 
                from tb_employee e 
                join tb_position p on e.id_position=p.id_position 
                join tb_employee_detail ed on e.id_employee=ed.id_employee
                where e.id_employee=$id_employee"); 
                return $query->result() ;
                      
        }

        function getAllEmployee(){
            $query = $this->db->query("SELECT e.id_employee,ed.name,ed.birthPlace,ed.birthDay,ed.lastEducation,e.id_position,p.name as position,e.username,e.password,e.contractStart,e.contractEnd,p.salary 
                from tb_employee e 
                join tb_position p on e.id_position=p.id_position 
                join tb_employee_detail ed on e.id_employee=ed.id_employee");
        return $query->result() ;        
        }

        function insertEmployee($name,$birthPlace,$birthDay,$lastEducation,$id_position,$username,$password,$contractStart,$contractEnd){
            $query1 = $this->db->query("INSERT INTO tb_employee (id_position,username,password,contractStart,contractEnd) 
                values ('$id_position','$username','$password','$contractStart','$contractEnd')");
            $query2 = $this->db->query("INSERT INTO tb_employee_detail (id_employee, name, birthPlace, birthDay, lastEducation) 
                select id_employee,'$name','$birthPlace','$birthDay','$lastEducation' 
                from tb_employee  
                order by id_employee 
                DESC LIMIT 1");
        return false;
        }

        function updateEmployee($id_employee,$name,$birthPlace,$birthDay,$id_position,$contractStart,$contractEnd){
            $query = $this->db->query("UPDATE tb_employee e,tb_employee_detail ed SET ed.name='$name',ed.birthPlace='$birthPlace',ed.birthDay='$birthDay',e.id_position='$id_position', e.contractStart='$contractStart',e.contractEnd='$contractEnd' where e.id_employee=ed.id_employee and e.id_employee='$id_employee'");
        return true; 
        }

        function deleteEmployee($id_employee){
            $query = $this->db->query("DELETE FROM tb_employee where id_employee='$id_employee'");
        return true;
        }


/*  ------------------------------ END OF SQL CRUD EMPLOYEE -----------------------------------------------------*/
        
        function checkPositionByName($name){
            $query = $this->db->query("SELECT * from tb_position where name='$name'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function checkPositionByID($id_position){
            $query = $this->db->query("SELECT * from tb_position where id_position='$id_position'"); 
                if($query->num_rows() > 0) {
                    return true; 
                } 
                else {
                    return false;
               }
        }

        function getPosition($id_position){
            $query = $this->db->query("SELECT * from tb_position where id_position='$id_position'"); 
        return $query->result() ;
        }

        function getAllPosition(){
            $query = $this->db->query("SELECT * from tb_position"); 
        return $query->result() ;
        }

        function insertPosition($name,$salary){
            $query = $this->db->query("INSERT INTO tb_position(name,salary) VALUES ('$name','$salary')");
        return false;
        }

        function updatePosition($id_position,$name,$salary){
            $query = $this->db->query("UPDATE tb_position SET name='$name',salary='$salary' where id_position='$id_position'");
        return true ;
        }

        function deletePosition($id_position){
            $query = $this->db->query("DELETE FROM tb_position where id_position='$id_position'");
        return true ;
        }
/* ---------------------------------- END OF CRUD POSITION ----------------------------------------------- */
        
        function checkCustomerByName($name){
            $query = $this->db->query("SELECT * from tb_customer where name='$name'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function checkCustomerByID($id_customer){
            $query = $this->db->query("SELECT * from tb_customer where id_customer='$id_customer'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function getCustomer($id_customer){
            $query = $this->db->query("SELECT * from tb_customer c join tb_customer_status cs on c.id_customer_status=cs.id_customer_status where id_customer='$id_customer'"); 
        return $query->result() ;
        }

        function getAllCustomer(){
            $query = $this->db->query("SELECT * FROM tb_customer c join tb_customer_status cs on c.id_customer_status=cs.id_customer_status") ;
        return $query->result();        
        }        
        
        function insertCustomer($id_customer_status,$name,$address,$telephone){
            $query = $this->db->query("INSERT INTO tb_customer (id_customer_status,name,address,telephone) VALUES ('$id_customer_status','$name','$address','$telephone')");
        return false ;
        }

        function updateCustomer($id_customer,$id_customer_status,$name,$address,$telephone){
            $query = $this->db->query("UPDATE tb_customer SET id_customer_status='$id_customer_status',name='$name',address='$address',telephone='$telephone' where id_customer='$id_customer'");
        return true ;
        }

        function deleteCustomer($id_customer){
            $query = $this->db->query("DELETE FROM tb_customer where id_customer='$id_customer'");
        return true ;
        }

/* ------------------------------------ END OF SQL CRUD CUSTOMERS ----------------------------------------- */
        function checkInventoryByName($name){
            $query = $this->db->query("SELECT * from tb_inventory where name='$name'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function checkInventoryByID($id_inventory){
            $query = $this->db->query("SELECT * from tb_inventory where id_inventory='$id_inventory'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function getInventory($id_inventory){
            $query = $this->db->query("SELECT * from tb_inventory where id_inventory='$id_inventory'"); 
        return $query->result() ;
        }

        function getAllInventory(){
            $query = $this->db->query("SELECT * from tb_inventory"); 
        return $query->result() ;
        }

        function insertInventory($name,$amount,$description){
            $query = $this->db->query("INSERT INTO tb_inventory (name,amount,description) VALUES ('$name','$amount','$description')");
        return false ;
        }

        function updateInventory($id_inventory,$name,$amount,$description){
            $query = $this->db->query("UPDATE tb_inventory SET name='$name',amount='$amount',description='$description' where id_inventory='$id_inventory'");
        return true ;
        }

        function deleteInventory($id_inventory){
            $query = $this->db->query("DELETE FROM tb_inventory where id_inventory='$id_inventory'");
        return true ;
        }

/* -------------------------------- END OF SQL CRUD INVENTORY -------------------------------------------- */
        function checkTableByID($id_table){
            $query = $this->db->query("SELECT * from tb_table where id_table='$id_table'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function getTable($id_table){
            $query = $this->db->query("SELECT t.id_table,t.id_status,ts.description from tb_table t join tb_table_status ts on t.id_status=ts.id_status where id_table='$id_table'"); 
        return $query->result() ;
        }

        function getAllTable(){
            $query = $this->db->query("SELECT t.id_table,ts.description from tb_table t join tb_table_status ts on t.id_status=ts.id_status"); 
        return $query->result() ;
        }

        function insertTable($id_table,$id_status){
            $query = $this->db->query("INSERT INTO tb_table (id_table,id_status) VALUES ('$id_table','$id_status')");
        return false ;
        }

        function updateTable($id_table,$id_status){
            $query = $this->db->query("UPDATE tb_table SET id_table='$id_table',id_status='$id_status' where id_table='$id_table'");
        return true ;
        }

        function deleteTable($id_table){
            $query = $this->db->query("DELETE FROM tb_table where id_table='$id_table'");
        return true ;
        }
/*  ------------------- END OF SQL CRUD TABLE -----------------------------------------------*/

        function checkMenuByName($name){
            $query = $this->db->query("SELECT * from tb_menu where name='$name'"); 
                if($query->num_rows() > 0) {
                    return true; 
                } 
                else {
                    return false;
               }
        }

        function checkMenuByID($id_menu){
            $query = $this->db->query("SELECT * from tb_menu where id_menu='$id_menu'"); 
                if($query->num_rows() > 0) {
                    return true; 
                } 
                else {
                    return false;
               }
        }
        function getMenu($id_menu){
            $query = $this->db->query("SELECT * from tb_menu where id_menu='$id_menu'"); 
        return $query->result() ;
        }

        function getAllMenu(){
            $query = $this->db->query("SELECT * from tb_menu"); 
        return $query->result() ;
        }

        function insertMenu($id_types_of_menu,$name,$price,$picture,$description){
            $query = $this->db->query("INSERT INTO tb_menu (id_types_of_menu,name,price,picture,description) VALUES ('$id_types_of_menu','$name','$price','$picture','$description')");
        return false ;
        }

        function updateMenu($id_menu,$name,$price,$description){
            $query = $this->db->query("UPDATE tb_menu SET name='$name',price='$price',description='$description' where id_menu='$id_menu'");
        return true ;
        }

        function deleteMenu($id_menu){
            $query = $this->db->query("DELETE FROM tb_menu where id_menu='$id_menu'");
        return true ;
        }

/* ----------------------------------- END OF CRUD FOOD MENU ------------------------------------------------ */
        

        function checkToMByName($name){
            $query = $this->db->query("SELECT * from tb_types_of_menu where name='$name'"); 
                if($query->num_rows() > 0) {
                    return true; 
                } 
                else {
                    return false;
               }
        }

        function checkToMByID($id_types_of_menu){
            $query = $this->db->query("SELECT * from tb_types_of_menu where id_types_of_menu='$id_types_of_menu'"); 
                if($query->num_rows() > 0) {
                    return true; 
                } 
                else {
                    return false;
               }
        }
        function getToM($id_types_of_menu){
            $query = $this->db->query("SELECT * from tb_types_of_menu where id_types_of_menu='$id_types_of_menu'"); 
        return $query->result() ;
        }

        function getAllToM(){
            $query = $this->db->query("SELECT * from tb_types_of_menu"); 
        return $query->result() ;
        }

        function insertToM($name,$description){
            $query = $this->db->query("INSERT INTO tb_types_of_menu (name,description) VALUES ('$name','$description')");
        return false ;
        }

        function updateToM($id_types_of_menu,$name){
            $query = $this->db->query("UPDATE tb_types_of_menu SET name='$name' where id_types_of_menu='$id_types_of_menu'");
        return true ;
        }

        function deleteToM($id_types_of_menu){
            $query = $this->db->query("DELETE FROM tb_types_of_menu where id_types_of_menu='$id_types_of_menu'");
        return true ;
        }

/* ----------------------------------- END OF CRUD TYPES OF MENU ------------------------------------------- */

        function checkOrderByID($id_transaction){
            $query = $this->db->query("SELECT * from tb_order where id_transaction='$id_transaction'"); 
                if($query->num_rows() > 0) {
                        return true; 
                } 
                else {
                        return false;
               }
        }

        function getOrder($id_transaction){
            $query = $this->db->query("SELECT * from tb_order where id_transaction='$id_transaction'"); 
        return $query->result() ;
        }

        function getAllOrder(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status"); 
        return $query->result() ;
        }

        function insertOrder($id_transaction,$id_customer,$id_table,$id_menu,$PIC_Waitress,$PIC_Chef,$quantity,$date,$timeOrderPlaced,$timeOrderCooked,$timeOrderChecked,$timeOrderAccepted,$timePaid,$id_order_status){
            $query = $this->db->query("INSERT INTO tb_order (id_transaction,id_customer,id_table,id_menu,PIC_Waitress,PIC_Chef,quantity,date,timeOrderPlaced,timeOrderCooked,timeOrderChecked,timeOrderAccepted,timePaid,id_order_status) VALUES ($id_transaction,$id_customer,$id_table,$id_menu,$PIC_Waitress,$PIC_Chef,$quantity,$date,$timeOrderPlaced,$timeOrderCooked,$timeOrderChecked,$timeOrderAccepted,$timePaid,$id_order_status) ");
        return false;
        }

        function updateOrder($id_transaction,$id_table,$id_menu,$quantity,$id_order_status,$date,$timeOrderPlaced,$timeOrderCooked,$timeOrderChecked,$timeOrderAccepted,$timePaid){
            $query = $this->db->query("UPDATE tb_order SET id_table='$id_table',id_menu='$id_menu',quantity='$quantity',id_order_status='$id_order_status',date='$date',timeOrderPlaced='$timeOrderPlaced',timeOrderCooked='$timeOrderCooked',timeOrderChecked='$timeOrderChecked',timeOrderAccepted='$timeOrderAccepted',timePaid='$timePaid' where id_transaction='$id_transaction'");
        return true ;
        }

        function deleteOrder(){
                $query = $this->db->query("DELETE FROM tb_order where id_transaction='$id_transaction'");
        return true ;
        }

/* ---------------------------------- END OF CRUD ORDER ---------------------------------------------- */
        
/*  --------------------------------- START OF COOKED FUNCTION ---------------------------------------------*/         
        function getCooked(){

        }

        function getAllCooked(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=2"); 
        return $query->result() ;
        }

        function updateCooked(){

        }

/*  --------------------------------- START OF CHECKED FUNCTION ---------------------------------------------*/        
        function getChecked(){

        }

        function getAllChecked(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=3"); 
        return $query->result() ;
        }

        function updateChecked(){

        }

/*  --------------------------------- START OF ACCEPTED FUNCTION ---------------------------------------------*/        
        function getAccepted(){

        }

        function getAllAccepted(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=4"); 
        return $query->result() ;
        }

        function updateAccepted(){

        }

/*  --------------------------------- START OF PAID FUNCTION ---------------------------------------------*/            
        function getPaid(){

        }

        function getAllPaid(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=5"); 
        return $query->result() ;
        }

        function updatePaid(){

        }

/*  --------------------------------- START OF RESERVED FUNCTION ---------------------------------------------*/        
        function getReserved(){

        }

        function getAllReserved(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=6"); 
        return $query->result() ;
        }

        function updateReserved(){

        }

/*  --------------------------------- START DONE STATUS ---------------------------------------------*/        
        
        function getDone(){

        }

        function getAllDone(){
            $query = $this->db->query("SELECT o.id_transaction,o.id_customer,c.name as name,o.id_table,o.id_menu,m.name as menu,o.PIC_Waitress,o.PIC_Chef,o.quantity,o.date,o.timeOrderPlaced,o.timeOrderCooked,o.timeOrderChecked,o.timeOrderAccepted,o.timePaid,o.id_order_status,os.description from tb_order o 
                join tb_customer c on o.id_customer=c.id_customer
                join tb_menu m on o.id_menu=m.id_menu
                join tb_order_status os on o.id_order_status=os.id_order_status
                where o.id_order_status=7"); 
        return $query->result() ;
        }

}
?>
