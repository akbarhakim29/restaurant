<section id="signIn" class="content-section text-center">
        <div class="download-section">
            <div class="container">
                <div class="col-md-5 col-lg-offset-4">
				    <h2>SIGN IN</h2>			  	
						<?php echo validation_errors(); ?>
						<?php echo form_open('api/getMenu'); ?>
						<form role="form" >
							<fieldset>
								
								<div class="form-group">
									<input class="form-control" placeholder="Username" type="text" name="id_menu" required/>
								</div>
								
								<button type="submit" value="submit" class="btn btn-primary btn-lg">SIGN IN</button>
								
							</fieldset>
						</form>
						<?php form_close(); ?>
				<br>
				<h5>Belum punya akun? <?php echo anchor('user/signup', 'Sign up !'); ?></h5>
				
                    
                </div>
            </div>
        </div>
    </section>