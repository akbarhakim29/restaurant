<section id="signIn" class="content-section text-center">
        <div class="download-section">
            <div class="container">
                <div class="col-md-5 col-lg-offset-4">
				    <h2>SIGN IN</h2>			  	
						<?php echo validation_errors(); ?>
						<?php echo form_open('api/updatePosition'); ?>
						<form role="form" >
							<fieldset>
								<div class="form-group">
									<input class="form-control" placeholder="id" type="text" name="id_position" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="Name" type="text" name="name" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="Salary" type="text" name="salary" required/>
								</div>
								<!-- <div class="form-group">
									<input class="form-control" placeholder="BirthDay (ex: 1991-08-08)" type="text" name="birthDay" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="Last Education (ex: S1/S2/S3)" type="text" name="lastEducation" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="id_position" type="text" name="id_position" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="Username" type="text" name="username" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="Password" type="password" name="password" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="contractStart (ex: 1991-08-08)" type="text" name="contractStart" required/>
								</div>
								<div class="form-group">
									<input class="form-control" placeholder="contractEnd (ex: 1991-08-08)" type="text" name="contractEnd" required/>
								</div> -->
																
								<button type="submit" value="submit" class="btn btn-primary btn-lg">SIGN IN</button>
								
							</fieldset>
						</form>
						<?php form_close(); ?>
				<br>
				<h5>Belum punya akun? <?php echo anchor('user/signup', 'Sign up !'); ?></h5>
				
                    
                </div>
            </div>
        </div>
    </section>