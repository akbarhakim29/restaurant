<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Api extends CI_Controller{
	
	public function __construct(){
			parent::__construct();
			$this->load->model('resto_model');
			$this->load->helper(array('form', 'url'));
			$this->load->library('session');		
	}

	public function index(){
		$this->load->view('get_one');
	}

	public function checkEmployee(){

		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$response = array();

		$check = $this->resto_model->checkEmployeeByUsername($username,$password);
		if ($check == true) {
			
			$response["code"] = 200 ;
			$response["message"] = "OK" ;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;		
		}
		
		echo json_encode($response);
	}
	/*public function setEmployee(){
		$this->load->view('get_one');
	}*/
	public function login(){
		
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$response = array();
		$data = $this->resto_model->login($username,$password);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK";
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
		
		echo json_encode($response);
	}

	public function getEmployee(){
		
		$id_employee = $this->input->post('id_employee');
		
		$response = array();
		$data = $this->resto_model->getEmployee($id_employee);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK";
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
		
		echo json_encode($response);
	}

	public function getAllEmployee(){
		$data = $this->resto_model->getAllEmployee();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	/*public function setInsertEmployee(){
		$this->load->view('insert');
	}*/

	public function insertEmployee(){
		$name = $this->input->post('name');
		$birthPlace = $this->input->post('birthPlace');
		$birthDay = $this->input->post('birthDay');
		$lastEducation = $this->input->post('lastEducation');

		$id_position = $this->input->post('id_position');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$contractStart = $this->input->post('contractStart');
		$contractEnd = $this->input->post('contractEnd');
		
		$check=$this->resto_model->checkEmployeeByUsername($username,$password);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this account was created";
		}
		else{
			$this->resto_model->insertEmployee($name,$birthPlace,$birthDay,$lastEducation,$id_position,$username,$password,$contractStart,$contractEnd);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		echo json_encode($response);
	}

	/*public function setUpdateEmployee(){
		$this->load->view('update');
	}*/

	public function updateEmployee(){
		$id_employee = $this->input->post('id_employee');
		$name = $this->input->post('name');
		$birthPlace = $this->input->post('birthPlace');
		$birthDay = $this->input->post('birthDay');
		$id_position = $this->input->post('id_position');
		$contractStart = $this->input->post('contractStart');
		$contractEnd = $this->input->post('contractEnd');

		$check=$this->resto_model->checkEmployeeByID($id_employee);
		if($check == true){
			$this->resto_model->updateEmployee($id_employee,$name,$birthPlace,$birthDay,$id_position,$contractStart,$contractEnd);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No database";
		}
		echo json_encode($response) ;

	}

	/*public function setdeleteEmployee(){
		$this->load->view('delete');
	}*/

	public function deleteEmployee(){
		$id_employee = $this->input->post('id_employee');
			$check=$this->resto_model->checkEmployeeByID($id_employee);
			if ($check == true) {
				$this->resto_model->deleteEmployee($id_employee);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/*---------- end of CRUD EMPLOYEE ----------------------*/
	public function getPosition(){
		$id_position = $this->input->post('id_position');
		
		$response = array();
		$data = $this->resto_model->getPosition($id_position);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllPosition(){
		$data = $this->resto_model->getAllPosition();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertPosition(){
		$name = $this->input->post('name');
		$salary = $this->input->post('salary');
		
		$check=$this->resto_model->checkPositionByName($name);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this account was created";
		}
		else{
			$this->resto_model->insertPosition($name,$salary);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		echo json_encode($response);
	}

	public function updatePosition(){
		$id_position = $this->input->post('id_position');
		$name = $this->input->post('name');
		$salary = $this->input->post('salary');
		
		$check=$this->resto_model->checkPositionByID($id_position);
		if ($check == true) {
			$this->resto_model->updatePosition($id_position,$name,$salary);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deletePosition(){
		$id_position = $this->input->post('id_position');
			$check=$this->resto_model->checkPositionByID($id_position);
			if ($check == true) {
				$this->resto_model->deletePosition($id_position);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/* ------ END OF CRUD POSITION --------------------------- */

	public function getCustomer(){
		$id_customer = $this->input->post('id_customer');
		
		$response = array();
		$data = $this->resto_model->getCustomer($id_customer);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllCustomer(){
		$data = $this->resto_model->getAllCustomer();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertCustomer(){
		$id_customer_status = $this->input->post('id_customer_status');
		$name = $this->input->post('name');
		$address = $this->input->post('address');
		$telephone = $this->input->post('telephone');
		
			$this->resto_model->insertCustomer($id_customer_status,$name,$address,$telephone);
			$response["code"] = 200;
			$response["message"] = "OK";

		echo json_encode($response);
	}

	public function updateCustomer(){
		$id_customer = $this->input->post('id_customer');
		$id_customer_status = $this->input->post('id_customer_status');
		$name = $this->input->post('name');
		$address = $this->input->post('address');
		$telephone = $this->input->post('telephone');
		
		$check=$this->resto_model->checkCustomerByID($id_customer);
		if ($check == true) {
			$this->resto_model->updateCustomer($id_customer,$id_customer_status,$name,$address,$telephone);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteCustomer(){
		$id_customer = $this->input->post('id_customer');
			$check=$this->resto_model->checkCustomerByID($id_customer);
			if ($check == true) {
				$this->resto_model->deleteCustomer($id_customer);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/* -------------- END OF CRUD CUSTOMER ---------------------- */
	
	public function getInventory(){
		$id_inventory = $this->input->post('id_inventory');
		
		$response = array();
		$data = $this->resto_model->getInventory($id_inventory);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllInventory(){
		$data = $this->resto_model->getAllInventory();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertInventory(){
		$name = $this->input->post('name');
		$amount = $this->input->post('amount');
		$description = $this->input->post('description');
		
		$check=$this->resto_model->checkInventoryByName($name);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this data was created";
		}
		else{
			$this->resto_model->insertInventory($name,$amount,$description);
			$response["code"] = 200;
			$response["message"] = "OK";
		}

		echo json_encode($response);
	}

	public function updateInventory(){
		$id_inventory = $this->input->post('id_inventory');
		$name = $this->input->post('name');
		$amount = $this->input->post('amount');
		$description = $this->input->post('description');
		
		$check=$this->resto_model->checkInventoryByID($id_inventory);
		if ($check == true) {
			$this->resto_model->updateInventory($id_inventory,$name,$amount,$description);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteInventory(){
		$id_inventory = $this->input->post('id_inventory');
			$check=$this->resto_model->checkInventoryByID($id_inventory);
			if ($check == true) {
				$this->resto_model->deleteInventory($id_inventory);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	} 
/* ----------- END OF CRUD Inventory ------------------------ */
	
	public function getMenu(){
		$id_menu = $this->input->post('id_menu');
		
		$response = array();
		$data = $this->resto_model->getMenu($id_menu);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllMenu(){
		$data = $this->resto_model->getAllMenu();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
		/*$code = isset($_GET['code'])?$_GET['code']:"";
		$view = isset($_GET['view'])?$_GET['view']:"";
		if($code == "123"){
			if(!empty($view)){*/
				/*echo "<pre>";*/
				echo json_encode($response);
				/*echo "</pre>";*/
			/*}else{
				echo json_encode($response,JSON_PRETTY_PRINT);
			}
		}*/
        
	}	

	public function insertMenu(){
		$id_types_of_menu = $this->input->post('id_types_of_menu');
		$name = $this->input->post('name');
		$price = $this->input->post('price');
		$namepic = $this->input->post('namepic');
		$picture = $this->input->post('picture');
		$description = $this->input->post('description');
		
		$date = date('Ymd His');
		/*$file_name = isset($namepic)?$namepic:"kosong" ;*/
		$path = "upload/".$namepic."-".$date.".jpeg" ;
		$url = "http://localhost/restoserver/".$path ;
		if (file_put_contents($path, base64_decode($picture)) != false) 
			

		$check=$this->resto_model->checkMenuByName($name);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this data was created";
		}
		else{
			if(file_put_contents($path, base64_decode($picture)) != false){
				$this->resto_model->insertMenu($id_types_of_menu,$name,$price,$url,$description);
				$response["code"] = 200;
				$response["message"] = "OK";	
			}
			else {
				$response["message"] = "Upload failed";
			}	
		}
		echo json_encode($response);
	}

	public function updateMenu(){
		$id_menu = $this->input->post('id_menu');
		/*$id_types_of_menu = $this->input->post('id_types_of_menu');*/
		$name = $this->input->post('name');
		$price = $this->input->post('price');
		/*$picture = $this->input->post('picture');*/
		$description = $this->input->post('description');
		
		$check=$this->resto_model->checkMenuByID($id_menu);
		if ($check == true) {
			$this->resto_model->updateMenu($id_menu,$name,$price,$description);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteMenu(){
		$id_menu = $this->input->post('id_menu');
			$check=$this->resto_model->checkMenuByID($id_menu);
			if ($check == true) {
				$this->resto_model->deleteMenu($id_menu);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/* ------------- END OF CRUD MENU --------------------------- */

	public function getToM(){
		$id_types_of_menu = $this->input->post('id_types_of_menu');
		
		$response = array();
		$data = $this->resto_model->getToM($id_types_of_menu);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllToM(){
		$data = $this->resto_model->getAllToM();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertToM(){
		$name = $this->input->post('name');
		$description = $this->input->post('description');
		
		$check=$this->resto_model->checkToMByName($name);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this data was created";
		}
		else{
			$this->resto_model->insertToM($name,$description);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		echo json_encode($response);
	}

	public function updateToM(){
		$id_types_of_menu = $this->input->post('id_types_of_menu');
		$name = $this->input->post('name');
		
		$check=$this->resto_model->checkToMByID($id_types_of_menu);
		if ($check == true) {
			$this->resto_model->updateToM($id_types_of_menu,$name);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteToM(){
		$id_types_of_menu = $this->input->post('id_types_of_menu');
			$check=$this->resto_model->checkToMByID($id_types_of_menu);
			if ($check == true) {
				$this->resto_model->deleteToM($id_types_of_menu);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/* ------------- END OF CRUD TYPES OF MENU --------------------------- */

	public function getTable(){
		$id_table = $this->input->post('id_table');
		
		$response = array();
		$data = $this->resto_model->getTable($id_table);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllTable(){
		$data = $this->resto_model->getAllTable();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertTable(){
		$id_table = $this->input->post('id_table');
		$id_status = $this->input->post('id_status');
		
		$check=$this->resto_model->checkTableByID($id_table);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this data was created";
		}
		else{
			$this->resto_model->insertTable($id_table,$id_status);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		echo json_encode($response);
	}

	public function updateTable(){
		$id_table = $this->input->post('id_table');
		$id_status = $this->input->post('id_status');
		
		$check=$this->resto_model->checkTableByID($id_table);
		if ($check == true) {
			$this->resto_model->updateTable($id_table,$id_status);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteTable(){
		$id_table = $this->input->post('id_table');
			$check=$this->resto_model->checkTableByID($id_table);
			if ($check == true) {
				$this->resto_model->deleteTable($id_table);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/* ------------- END OF CRUD TABLE ----------------------------- */

	public function getOrder(){
		$id_transaction = $this->input->post('id_transaction');
		
		$response = array();
		$data = $this->resto_model->getOrder($id_transaction);
		$count = count($data);
		
		if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}	
		echo json_encode($response);
	}

	public function getAllOrder(){
		$data = $this->resto_model->getAllOrder();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function insertOrder(){
		$id_transaction = $this->input->post('id_transaction');
		$id_customer = $this->input->post('id_customer');
		$id_table = $this->input->post('id_table');
		$id_menu = $this->input->post('id_menu');
		$PIC_Waitress = $this->input->post('PIC_Waitress');
		$PIC_Chef = $this->input->post('PIC_Chef');
		$quantity = $this->input->post('quantity');
		$date = $this->input->post('date');
		$timeOrderPlaced=$this->input->post('timeOrderPlaced');
		$timeOrderCooked=$this->input->post('timeOrderCooked');
		$timeOrderChecked=$this->input->post('timeOrderChecked');
		$timeOrderAccepted=$this->input->post('timeOrderAccepted');
		$timePaid=$this->input->post('timePaid');
		$id_order_status=$this->input->post('id_order_status');
		
		$check=$this->resto_model->checkOrderByID($id_transaction);
		if ($check == true) {
			$response["code"] = 409;
			$response["message"] = "this data was created";
		}
		else{
			$this->resto_model->insertOrder($id_transaction,$id_customer,$id_table,$id_menu,$PIC_Waitress,$PIC_Chef,$quantity,$date,$timeOrderPlaced,$timeOrderCooked,$timeOrderChecked,$timeOrderAccepted,$timePaid,$id_order_status);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		echo json_encode($response);
	}

	public function updateOrder(){
		$id_transaction = $this->input->post('id_transaction');
		$id_table = $this->input->post('id_table');
		$id_menu = $this->input->post('id_menu');
		$quantity = $this->input->post('quantity');
		$date = $this->input->post('date');
		$timeOrderPlaced=$this->input->post('timeOrderPlaced');
		$timeOrderCooked=$this->input->post('timeOrderCooked');
		$timeOrderChecked=$this->input->post('timeOrderChecked');
		$timeOrderAccepted=$this->input->post('timeOrderAccepted');
		$timePaid=$this->input->post('timePaid');
		$id_order_status=$this->input->post('id_order_status');
		
		$check=$this->resto_model->checkOrderByID($id_transaction);
		if ($check == true) {
			$this->resto_model->updateOrder($id_transaction,$id_table,$id_menu,$quantity,$id_order_status,$date,$timeOrderPlaced,$timeOrderCooked,$timeOrderChecked,$timeOrderAccepted,$timePaid);
			$response["code"] = 200;
			$response["message"] = "OK";
		}
		else{
			$response["code"] = 204;
			$response["message"] = "No Database";
		}
		echo json_encode($response);
	}

	public function deleteOrder(){
		$id_transaction = $this->input->post('id_transaction');
			$check=$this->resto_model->checkOrderByID($id_transaction);
			if ($check == true) {
				$this->resto_model->deleteOrder($id_transaction);
				$response["code"] = 200;
				$response["message"] = "OK";
			}
		echo json_encode($response) ;
	}
/*  ----------------------------- END OF CRUD ORDER -------------------- */
	
/*  ----------------------------- START OF COOKED FUNCTION ----------------- */
	public function getCooked(){

	}

	public function getAllCooked(){
		$data = $this->resto_model->getAllCooked();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function updateCooked(){

	}

/*  -------------------------------- START OF CHECKED FUNCTION --------------- */
	
	public function getChecked(){

	}

	public function getAllChecked(){
		$data = $this->resto_model->getAllChecked();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function updateChecked(){

	}

/*  ---------------------------- START OF ACCEPTED FUNCTION ----------------------- */

	public function getAccepted(){

	}

	public function getAllAccepted(){
		$data = $this->resto_model->getAllAccepted();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function updateAccepted(){

	}

/*  ---------------------------- START OF PAID FUNCTION -------------------------- */

	public function getPaid(){

	}

	public function getAllPaid(){
		$data = $this->resto_model->getAllPaid();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function updatePaid(){

	}

/*  ------------------------------ START OF RESERVED FUNCTION ------------------------- */

public function getReserved(){

	}

	public function getAllReserved(){
		$data = $this->resto_model->getAllReserved();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}

	public function updateReserved(){

	}

/*  ------------------------------ START DONE STATUS ------------------------------ */

	public function getDone(){

	}

	public function getAllDone(){
		$data = $this->resto_model->getAllDone();
		$response = array();
        $count = count($data);
        
        if ($count>0) {
			$response["code"] = 200;
			$response["message"] = "OK" ;
			$response["data"]= $data;
		}
		else{
			$response["code"] = 204 ;
			$response["message"] = "No Content" ;
		}
        echo json_encode($response);
	}


}
	
?>

