-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 07 Nov 2016 pada 09.39
-- Versi Server: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_customer`
--

CREATE TABLE `tb_customer` (
  `id_customer` int(11) NOT NULL,
  `id_customer_status` int(1) NOT NULL,
  `name` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `telephone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_customer`
--

INSERT INTO `tb_customer` (`id_customer`, `id_customer_status`, `name`, `address`, `telephone`) VALUES
(1, 1, 'sugiyono', 'jl. TMP kalibata', '085731479204'),
(2, 2, 'parno', 'jl. Tebet timur', '085731479205');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_customer_status`
--

CREATE TABLE `tb_customer_status` (
  `id_customer_status` int(1) NOT NULL,
  `description` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_customer_status`
--

INSERT INTO `tb_customer_status` (`id_customer_status`, `description`) VALUES
(1, 'Member'),
(2, 'Not Member');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_employee`
--

CREATE TABLE `tb_employee` (
  `id_employee` int(5) NOT NULL,
  `id_position` int(3) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `contractStart` date NOT NULL,
  `contractEnd` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_employee`
--

INSERT INTO `tb_employee` (`id_employee`, `id_position`, `username`, `password`, `contractStart`, `contractEnd`) VALUES
(1, 1, 'owner', 'owner', '2016-08-01', '2017-12-31'),
(2, 2, 'CEO', 'CEO', '2016-08-01', '2017-12-31'),
(3, 3, 'CTO', 'CTO', '2016-08-01', '2017-12-31'),
(4, 7, 'admin', 'admin', '2016-08-08', '2017-12-31'),
(6, 5, 'cashier', 'cashiers', '2016-08-08', '2017-12-31'),
(7, 6, 'chef', 'chef', '2016-08-08', '2017-12-31'),
(8, 5, 'kim bum', 'kimbum', '2016-10-28', '2017-10-28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_employee_detail`
--

CREATE TABLE `tb_employee_detail` (
  `id_employee` int(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `birthPlace` varchar(30) NOT NULL,
  `birthDay` date NOT NULL,
  `lastEducation` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_employee_detail`
--

INSERT INTO `tb_employee_detail` (`id_employee`, `name`, `birthPlace`, `birthDay`, `lastEducation`) VALUES
(1, 'Robertus', 'Bandung', '1991-08-08', 'S1'),
(2, 'Fanni', 'Jakarta', '1992-08-08', 'S1'),
(3, 'Irsanti', 'Jakarta', '1991-08-08', 'S1'),
(4, 'Hakim', 'Sidoarjo', '1993-05-29', 'S1'),
(6, 'Akbar', 'Lampung', '1991-08-08', 'SMA'),
(7, 'Dana', 'Jakarta', '1991-08-08', 'S1'),
(8, 'kim jong un', 'pati', '2010-10-28', 'S1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_inventory`
--

CREATE TABLE `tb_inventory` (
  `id_inventory` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `amount` int(5) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_inventory`
--

INSERT INTO `tb_inventory` (`id_inventory`, `name`, `amount`, `description`) VALUES
(1, 'Table', 30, 'Table with size 1,5 x 1,5 m'),
(2, 'Chair', 120, 'Wood chair single '),
(3, 'Computer', 5, 'Computer Lenovo (processor i5,RAM 2GB,Harddisk 1TB)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_menu`
--

CREATE TABLE `tb_menu` (
  `id_menu` int(3) NOT NULL,
  `id_types_of_menu` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(9) NOT NULL,
  `picture` varchar(150) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_menu`
--

INSERT INTO `tb_menu` (`id_menu`, `id_types_of_menu`, `name`, `price`, `picture`, `description`) VALUES
(1, 1, 'Fried Rice with pete', 20000, 'http://resepmagz.com/wp-content/uploads/2016/07/Resep-Spesial-Nasi-Goreng-Pete-Spesial.jpg', 'Fried Rice and chicken meatball'),
(2, 1, 'Fried Rice with Lamb meat', 20000, 'http://selerasa.com/images/nasi/nasi_goreng/Resep-Bumbu-Dan-Cara-Membuat-Nasi-Goreng-Kambing-Enak-Spesial-Khas-Betawi.jpg', 'Fried Rice and chicken meatball'),
(16, 1, 'soto daging', 16000, 'http://www.tokomesin.com/wp-content/uploads/2015/08/Resep-Soto-Daging-Sapi-Kuah-Segar-tokomesin.jpg', 'soto daging khas bandung'),
(22, 1, 'kopi jos', 10000, 'http://localhost/restoserver/upload/jostenan-20161031 085035.jpeg', 'jos tenan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order`
--

CREATE TABLE `tb_order` (
  `id_transaction` int(30) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_table` int(3) NOT NULL,
  `id_menu` int(3) NOT NULL,
  `PIC_Waitress` int(5) NOT NULL,
  `PIC_Chef` int(5) NOT NULL,
  `quantity` int(10) NOT NULL,
  `date` date NOT NULL,
  `timeOrderPlaced` time NOT NULL,
  `timeOrderCooked` time NOT NULL,
  `timeOrderChecked` time NOT NULL,
  `timeOrderAccepted` time NOT NULL,
  `timePaid` time NOT NULL,
  `id_order_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_order`
--

INSERT INTO `tb_order` (`id_transaction`, `id_customer`, `id_table`, `id_menu`, `PIC_Waitress`, `PIC_Chef`, `quantity`, `date`, `timeOrderPlaced`, `timeOrderCooked`, `timeOrderChecked`, `timeOrderAccepted`, `timePaid`, `id_order_status`) VALUES
(1, 1, 5, 1, 4, 6, 3, '2016-08-18', '16:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 1),
(1, 1, 5, 2, 4, 6, 4, '2016-08-18', '16:00:00', '00:00:00', '00:00:00', '00:00:00', '00:00:00', 4),
(2, 2, 2, 1, 1, 2, 3, '2016-10-19', '10:00:00', '10:00:00', '10:00:00', '10:00:00', '10:00:00', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_order_status`
--

CREATE TABLE `tb_order_status` (
  `id_order_status` int(1) NOT NULL,
  `description` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_order_status`
--

INSERT INTO `tb_order_status` (`id_order_status`, `description`) VALUES
(1, 'ordered'),
(2, 'cooked'),
(3, 'checked'),
(4, 'accepted'),
(5, 'paid'),
(6, 'reserved'),
(7, 'Done');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_payment`
--

CREATE TABLE `tb_payment` (
  `id_transaction` int(30) NOT NULL,
  `totalPayment` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_position`
--

CREATE TABLE `tb_position` (
  `id_position` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `salary` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_position`
--

INSERT INTO `tb_position` (`id_position`, `name`, `salary`) VALUES
(1, 'Owner', 15000000),
(2, 'CEO', 10000000),
(3, 'CTO', 10000000),
(5, 'Cashier', 4000000),
(6, 'Chef', 7000000),
(7, 'Admin', 0),
(8, 'Office Assistant', 3000000),
(9, 'Office Boy', 4000000),
(10, 'Office Girls', 500000),
(11, 'Designer', 6000000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_table`
--

CREATE TABLE `tb_table` (
  `id_table` int(3) NOT NULL,
  `id_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_table`
--

INSERT INTO `tb_table` (`id_table`, `id_status`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_table_status`
--

CREATE TABLE `tb_table_status` (
  `id_status` int(1) NOT NULL,
  `description` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_table_status`
--

INSERT INTO `tb_table_status` (`id_status`, `description`) VALUES
(1, 'Available'),
(2, 'Not Available');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_types_of_menu`
--

CREATE TABLE `tb_types_of_menu` (
  `id_types_of_menu` int(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_types_of_menu`
--

INSERT INTO `tb_types_of_menu` (`id_types_of_menu`, `name`, `description`) VALUES
(1, 'food', ''),
(2, 'drink', ''),
(3, 'cake', ''),
(4, 'dessert', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_customer`
--
ALTER TABLE `tb_customer`
  ADD PRIMARY KEY (`id_customer`,`id_customer_status`),
  ADD KEY `id_customer_status` (`id_customer_status`);

--
-- Indexes for table `tb_customer_status`
--
ALTER TABLE `tb_customer_status`
  ADD PRIMARY KEY (`id_customer_status`);

--
-- Indexes for table `tb_employee`
--
ALTER TABLE `tb_employee`
  ADD PRIMARY KEY (`id_employee`,`id_position`,`username`),
  ADD KEY `id_position` (`id_position`);

--
-- Indexes for table `tb_employee_detail`
--
ALTER TABLE `tb_employee_detail`
  ADD PRIMARY KEY (`id_employee`);

--
-- Indexes for table `tb_inventory`
--
ALTER TABLE `tb_inventory`
  ADD PRIMARY KEY (`id_inventory`);

--
-- Indexes for table `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD PRIMARY KEY (`id_menu`,`id_types_of_menu`),
  ADD KEY `id_kind_of_menu` (`id_types_of_menu`);

--
-- Indexes for table `tb_order`
--
ALTER TABLE `tb_order`
  ADD PRIMARY KEY (`id_transaction`,`id_customer`,`id_table`,`id_menu`,`PIC_Waitress`,`PIC_Chef`,`id_order_status`),
  ADD KEY `id_order_status` (`id_order_status`),
  ADD KEY `id_table` (`id_table`),
  ADD KEY `id_menu` (`id_menu`),
  ADD KEY `PIC_Waitress` (`PIC_Waitress`),
  ADD KEY `PIC_Chef` (`PIC_Chef`),
  ADD KEY `id_customer` (`id_customer`);

--
-- Indexes for table `tb_order_status`
--
ALTER TABLE `tb_order_status`
  ADD PRIMARY KEY (`id_order_status`);

--
-- Indexes for table `tb_payment`
--
ALTER TABLE `tb_payment`
  ADD PRIMARY KEY (`id_transaction`);

--
-- Indexes for table `tb_position`
--
ALTER TABLE `tb_position`
  ADD PRIMARY KEY (`id_position`);

--
-- Indexes for table `tb_table`
--
ALTER TABLE `tb_table`
  ADD PRIMARY KEY (`id_table`,`id_status`),
  ADD KEY `id_status` (`id_status`);

--
-- Indexes for table `tb_table_status`
--
ALTER TABLE `tb_table_status`
  ADD PRIMARY KEY (`id_status`);

--
-- Indexes for table `tb_types_of_menu`
--
ALTER TABLE `tb_types_of_menu`
  ADD PRIMARY KEY (`id_types_of_menu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_customer`
--
ALTER TABLE `tb_customer`
  MODIFY `id_customer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_customer_status`
--
ALTER TABLE `tb_customer_status`
  MODIFY `id_customer_status` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_employee`
--
ALTER TABLE `tb_employee`
  MODIFY `id_employee` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_employee_detail`
--
ALTER TABLE `tb_employee_detail`
  MODIFY `id_employee` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_inventory`
--
ALTER TABLE `tb_inventory`
  MODIFY `id_inventory` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tb_menu`
--
ALTER TABLE `tb_menu`
  MODIFY `id_menu` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tb_order_status`
--
ALTER TABLE `tb_order_status`
  MODIFY `id_order_status` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tb_position`
--
ALTER TABLE `tb_position`
  MODIFY `id_position` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tb_types_of_menu`
--
ALTER TABLE `tb_types_of_menu`
  MODIFY `id_types_of_menu` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tb_customer`
--
ALTER TABLE `tb_customer`
  ADD CONSTRAINT `tb_customer_ibfk_1` FOREIGN KEY (`id_customer_status`) REFERENCES `tb_customer_status` (`id_customer_status`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_employee`
--
ALTER TABLE `tb_employee`
  ADD CONSTRAINT `tb_employee_ibfk_1` FOREIGN KEY (`id_position`) REFERENCES `tb_position` (`id_position`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_employee_detail`
--
ALTER TABLE `tb_employee_detail`
  ADD CONSTRAINT `tb_employee_detail_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `tb_employee` (`id_employee`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_menu`
--
ALTER TABLE `tb_menu`
  ADD CONSTRAINT `tb_menu_ibfk_1` FOREIGN KEY (`id_types_of_menu`) REFERENCES `tb_types_of_menu` (`id_types_of_menu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_order`
--
ALTER TABLE `tb_order`
  ADD CONSTRAINT `tb_order_ibfk_1` FOREIGN KEY (`id_order_status`) REFERENCES `tb_order_status` (`id_order_status`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_2` FOREIGN KEY (`id_table`) REFERENCES `tb_table` (`id_table`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_4` FOREIGN KEY (`id_menu`) REFERENCES `tb_menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_5` FOREIGN KEY (`PIC_Waitress`) REFERENCES `tb_employee` (`id_employee`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_6` FOREIGN KEY (`PIC_Chef`) REFERENCES `tb_employee` (`id_employee`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_order_ibfk_7` FOREIGN KEY (`id_customer`) REFERENCES `tb_customer` (`id_customer`);

--
-- Ketidakleluasaan untuk tabel `tb_payment`
--
ALTER TABLE `tb_payment`
  ADD CONSTRAINT `tb_payment_ibfk_1` FOREIGN KEY (`id_transaction`) REFERENCES `tb_order` (`id_transaction`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `tb_table`
--
ALTER TABLE `tb_table`
  ADD CONSTRAINT `tb_table_ibfk_1` FOREIGN KEY (`id_status`) REFERENCES `tb_table_status` (`id_status`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
